import 'package:flutter/material.dart';
import 'package:shifa_doc_app_v1/app/theme.dart';
import 'package:shifa_doc_app_v1/app/router.dart';

class ShifaDoctorApp extends StatelessWidget {
  const ShifaDoctorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Shifa Doctor',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      onGenerateRoute: AppRouter.onGenerateRoute,
      initialRoute: AppRoutes.splash, // Splash -> Verify -> Login -> App Shell
    );
  }
}
