// lib/features/home/presentation/home_screen.dart
import 'package:flutter/material.dart';
import 'package:shifa_doc_app_v1/app/router.dart';
import 'package:shifa_doc_app_v1/features/appointments/domain/appointment_models.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // Mock today's appointments (you can load from repo later)
  final List<Appointment> _appointments = [
    Appointment(
      id: 'a1',
      patientName: 'Jasur Karimov',
      location: 'Tashkent Med Center',
      start: const TimeOfDay(hour: 10, minute: 0),
      end: const TimeOfDay(hour: 10, minute: 30),
    ),
    Appointment(
      id: 'a2',
      patientName: 'Gulnora Yusupova',
      location: 'Video Consultation',
      start: const TimeOfDay(hour: 10, minute: 30),
      end: const TimeOfDay(hour: 11, minute: 0),
    ),
    Appointment(
      id: 'a3',
      patientName: 'Nodira Akhmedova',
      location: 'Video Consultation',
      start: const TimeOfDay(hour: 11, minute: 0),
      end: const TimeOfDay(hour: 11, minute: 30),
    ),
    Appointment(
      id: 'a4',
      patientName: 'Ulugbek Tursunov',
      location: 'Video Consultation',
      start: const TimeOfDay(hour: 12, minute: 0),
      end: const TimeOfDay(hour: 12, minute: 30),
    ),
  ];

  String? _selectedId;

  String _fmt(TimeOfDay t) =>
      '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Row(
          children: [
            // Left: Today
            Expanded(
              flex: 2,
              child: Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Today',
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 24),
                    Expanded(
                      child: ListView.separated(
                        itemCount: _appointments.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 16),
                        itemBuilder: (context, i) {
                          final appt = _appointments[i];
                          final selected = _selectedId == appt.id;
                          return _AppointmentItem(
                            appointment: appt,
                            selected: selected,
                            onTap: () => setState(() => _selectedId = appt.id),
                            onStart: () {
                              if (appt.isVideo) {
                                Navigator.pushNamed(
                                  context,
                                  AppRoutes.waitingRoom,
                                  arguments: appt,
                                );
                              } else {
                                Navigator.pushNamed(
                                  context,
                                  AppRoutes.inPerson,
                                  arguments: appt,
                                );
                              }
                            },
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(width: 24),

            // Right: Analytics + Shifa AI (placeholders kept)
            Expanded(
              flex: 3,
              child: Column(
                children: [
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.all(24),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Analytics',
                            style: TextStyle(
                              fontSize: 28,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 24),
                          Expanded(
                            child: Center(
                              child: Text(
                                'Analytics Dashboard\n(Charts & Graphs)',
                                style: TextStyle(
                                  fontSize: 16,
                                  color: Colors.grey.shade400,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Column(
                      children: [
                        SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Row(
                            children: const [
                              _QuickQuestion(
                                'Give me a summary of my next patients history',
                              ),
                              SizedBox(width: 12),
                              _QuickQuestion(
                                'Do I have any free slots next week Thursday?',
                              ),
                              SizedBox(width: 12),
                              _QuickQuestion(
                                'Do I have any free slots next week Thursday?',
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),
                        TextField(
                          decoration: InputDecoration(
                            hintText: 'Ask Shifa AI',
                            prefixIcon: const Icon(Icons.search),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide(
                                color: Colors.grey.shade300,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _AppointmentItem extends StatelessWidget {
  const _AppointmentItem({
    required this.appointment,
    required this.selected,
    required this.onTap,
    required this.onStart,
  });

  final Appointment appointment;
  final bool selected;
  final VoidCallback onTap;
  final VoidCallback onStart;

  String _fmt(TimeOfDay t) =>
      '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final brand = const Color(0xFF17C3B2);
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.grey.shade50,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: selected ? brand : Colors.grey.shade200,
            width: selected ? 2 : 1,
          ),
        ),
        child: Row(
          children: [
            // bullet
            Container(
              width: 16,
              height: 16,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: selected ? brand : Colors.grey.shade400,
                  width: 2,
                ),
              ),
              child: selected
                  ? const Icon(Icons.check, size: 10, color: Color(0xFF17C3B2))
                  : null,
            ),
            const SizedBox(width: 16),

            // time
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${_fmt(appointment.start)}\n${_fmt(appointment.end)}',
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
            const SizedBox(width: 16),

            // avatar (placeholder)
            CircleAvatar(
              radius: 20,
              backgroundColor: Colors.grey.shade300,
              child: Icon(Icons.person, color: Colors.grey.shade600),
            ),
            const SizedBox(width: 12),

            // name + location
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    appointment.patientName,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      if (appointment.isVideo)
                        const Icon(
                          Icons.videocam,
                          size: 14,
                          color: Colors.grey,
                        ),
                      if (appointment.isVideo) const SizedBox(width: 4),
                      Text(
                        appointment.location,
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey.shade600,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            // Start button only when selected
            if (selected)
              ElevatedButton(
                onPressed: onStart,
                style: ElevatedButton.styleFrom(
                  backgroundColor: brand,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 24,
                    vertical: 8,
                  ),
                ),
                child: const Text('Start'),
              ),
          ],
        ),
      ),
    );
  }
}

class _QuickQuestion extends StatelessWidget {
  const _QuickQuestion(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        border: Border.all(color: const Color(0xFF17C3B2)),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        text,
        style: const TextStyle(color: Color(0xFF17C3B2), fontSize: 12),
      ),
    );
  }
}
