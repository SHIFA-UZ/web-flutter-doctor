// lib/features/appointments/domain/appointment_models.dart
import 'package:flutter/material.dart';

class Appointment {
  final String id;
  final String patientName;
  final String location; // 'Video Consultation' or clinic name
  final TimeOfDay start;
  final TimeOfDay end;

  const Appointment({
    required this.id,
    required this.patientName,
    required this.location,
    required this.start,
    required this.end,
  });

  bool get isVideo => location.toLowerCase().contains('video');
}
