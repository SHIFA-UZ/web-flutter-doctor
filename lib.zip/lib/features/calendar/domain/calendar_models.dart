import 'package:flutter/material.dart';

enum EntryType { appointment, freeSlot }

class CalendarEntry {
  final EntryType type;
  final TimeOfDay start;
  final TimeOfDay end;

  // Appointment-only
  final String? patientName;
  final bool isVideo;
  final String location;
  final String reason;

  CalendarEntry.appointment({
    required this.start,
    required this.end,
    required this.patientName,
    required this.location,
    required this.reason,
    this.isVideo = false,
  }) : type = EntryType.appointment;

  CalendarEntry.freeSlot({required this.start, required this.end})
    : type = EntryType.freeSlot,
      patientName = null,
      isVideo = false,
      location = '',
      reason = '';
}
